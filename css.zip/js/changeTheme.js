const btndark = document.querySelector("#navbar__btn--dark");
let darkTheme;

//check in memory localstore
//todo:



btndark.addEventListener('click', event => {
    darkTheme = !darkTheme;

    event.stopPropagation();
})

function changeDarkMode() {
    document.body.classList.toggle("theme--light")
}